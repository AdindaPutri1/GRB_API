// publishers.js
const express = require("express");
const router = express.Router();
const pool = require("../db");

// CREATE
router.post("/", async (req, res) => {
  try {
    const { publisher_id, publisher_name, address, phone, email } = req.body;
    const query = "INSERT INTO publishers (publisher_id, publisher_name, address, phone, email) VALUES ($1, $2, $3, $4, $5) RETURNING *";
    const result = await pool.query(query, [publisher_id, publisher_name, address, phone, email]);
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// READ ALL
router.get("/", async (req, res) => {
  try {
    const query = "SELECT * FROM publishers";
    const result = await pool.query(query);
    res.status(200).json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// READ ONE
router.get("/:id", async (req, res) => {
  try {
    const id = req.params.id;
    const query = "SELECT * FROM publishers WHERE publisher_id = $1";
    const result = await pool.query(query, [id]);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Record not found" });
    }
    res.status(200).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// UPDATE
router.put("/:id", async (req, res) => {
  try {
    const id = req.params.id;
    const { publisher_name, address, phone, email } = req.body;
    const query = "UPDATE publishers SET publisher_name = $1, address = $2, phone = $3, email = $4 WHERE publisher_id = $5 RETURNING *";
    const result = await pool.query(query, [publisher_name, address, phone, email, id]);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Record not found" });
    }
    res.status(200).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE
router.delete("/:id", async (req, res) => {
  try {
    const id = req.params.id;
    const query = "DELETE FROM publishers WHERE publisher_id = $1 RETURNING *";
    const result = await pool.query(query, [id]);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Record not found" });
    }
    res.status(200).json({ message: "Record deleted successfully" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
